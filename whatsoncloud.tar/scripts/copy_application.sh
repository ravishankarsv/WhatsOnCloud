#!/bin/bash

cd /var/www/html
tar -xvf application.tar

